package org.firstinspires.ftc.teamcode.opmode.auto; // make sure this aligns with class location

import com.pedropathing.follower.Follower;
import com.pedropathing.geometry.BezierLine;
import com.pedropathing.geometry.Pose;
import com.pedropathing.paths.Path;
import com.pedropathing.paths.PathChain;
import com.pedropathing.util.Timer;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;

import org.firstinspires.ftc.teamcode.pedroPathing.Constants;


@Autonomous(name = "Red Mid Open")
    public class Autonomous_RedMid_Open extends OpMode {

    private DcMotor TopShooter;
    private DcMotor LowerShooter;
    private DcMotor rightRear;
    private DcMotor rightFront;
    private DcMotor leftRear;
    private DcMotor leftFront;
    private DcMotor Front;
    private DcMotor Middle;
    private Servo S1;
    private Servo S2;
    private Servo S3;
    private Servo S4;

    private Follower follower;
    private Timer pathTimer, actionTimer, opmodeTimer;
    private int pathState;


    private final Pose startPose = new Pose(0, 0, Math.toRadians(0)); // Start Pose of our robot.
    private final Pose scorePose = new Pose(75, -4, Math.toRadians(-40)); // Scoring Pose of our robot. It is facing the goal at a 135 degree angle.
    private final Pose P_keep1 = new Pose(78, -17 , Math.toRadians(-90)); // Pre 1
    private final Pose keep1 = new Pose(78, -44, Math.toRadians(-90)); // Keep 1
    private final Pose scorePose2 = new Pose(78, -8, Math.toRadians(-45));
    private final Pose P_keep2 = new Pose(57.2, -20, Math.toRadians(-90));
    private final Pose keep2 = new Pose(57.2, -45, Math.toRadians(-91));
    private final Pose scorePose3 = new Pose(78, -12, Math.toRadians(-45));
    private final Pose P_keep3 = new Pose(35, -25, Math.toRadians(-90));
    private final Pose keep3 = new Pose(35, -56, Math.toRadians(-90));
    private final Pose scorePose4 = new Pose(82, -14,  Math.toRadians(-45));
    private final Pose Final = new Pose(78, -32, Math.toRadians(-46));

    private Path scorePreload;
    private PathChain Pre_keep1, keep_1, scoring2, Pre_keep2, keep_2, scoring3, Finale;
        public void buildPaths() {
            /* This is our scorePreload path. We are using a BezierLine, which is a straight line. */
            scorePreload = new Path(new BezierLine(startPose, scorePose));
            scorePreload.setLinearHeadingInterpolation(startPose.getHeading(), scorePose.getHeading());

            Pre_keep1 = follower.pathBuilder()
                    .addPath(new BezierLine(scorePose, P_keep1))
                    .setLinearHeadingInterpolation(scorePose.getHeading(),P_keep1.getHeading())
                    .build();
            keep_1 = follower.pathBuilder()
                    .addPath(new BezierLine(P_keep1, keep1))
                    .setLinearHeadingInterpolation(P_keep1.getHeading(),keep1.getHeading())
                    .build();
            scoring2 = follower.pathBuilder()
                    .addPath(new BezierLine(keep1, scorePose2))
                    .setLinearHeadingInterpolation(keep1.getHeading(),scorePose2.getHeading())
                    .build();
            Pre_keep2 = follower.pathBuilder()
                    .addPath(new BezierLine(scorePose, P_keep2))
                    .setLinearHeadingInterpolation(scorePose.getHeading(),P_keep2.getHeading())
                    .build();
            keep_2 = follower.pathBuilder()
                    .addPath(new BezierLine(P_keep2, keep2))
                    .setLinearHeadingInterpolation(P_keep2.getHeading(),keep2.getHeading())
                    .build();
            scoring3 = follower.pathBuilder()
                    .addPath(new BezierLine(keep2, scorePose3))
                    .setLinearHeadingInterpolation(keep2.getHeading(),scorePose3.getHeading())
                    .build();
            Finale = follower.pathBuilder()
                    .addPath(new BezierLine(scorePose4, Final))
                    .setLinearHeadingInterpolation(scorePose4.getHeading(),Final.getHeading())
                    .build();

//            shoot = follower.pathBuilder()
//                 .addPath(new BezierLine(scorePose, P_keep1))
//                    .setLinearHeadingInterpolation(scorePose.getHeading(),P_keep1.getHeading())
//                    .build();

    /*
    /* Here is an example for Constant Interpolation
    scorePreload.setConstantInterpolation(startPose.getHeading()); */
            /* This is our grabPickup1 PathChain. We are using a single path with a BezierLine, which is a straight line. */

        }


        public void autonomousPathUpdate() throws InterruptedException {
            switch (pathState) {
                case 0:
                    TopShooter.setPower(0.78);
                    LowerShooter.setPower(0.78);

                    follower.setMaxPower(1);
                    follower.followPath(scorePreload);
                    setPathState(101);
                    break;
                case 101:
                    if (!follower.isBusy()) {
                        for (int i = 0; i <= 3; i++) {
                            switch (i) {
                                case 0:
                                    TopShooter.setPower(0.84);
                                    LowerShooter.setPower(0.84);
                                    break;
                                case 1:
                                    TopShooter.setPower(0.85);
                                    LowerShooter.setPower(0.85);
                                    break;
                                case 2:
                                    TopShooter.setPower(0.86);
                                    LowerShooter.setPower(0.86);
                                    break;
                            }

                            S3.setPosition(0.66);
                            S4.setPosition(0.52);
                            Middle.setPower(1);
                            Thread.sleep(300);

                            S3.setPosition(0);
                            S4.setPosition(0.36);
                            Middle.setPower(-0.9);
                            Thread.sleep(300);

                            Front.setPower(1);
                            Middle.setPower(1);
                            Thread.sleep(500);

                            Front.setPower(0);
                            Middle.setPower(0);
                            Thread.sleep(10);
                        }
                        setPathState(1);
                        break;
                    }
                case 1:
                    if (!follower.isBusy()){
                        Front.setPower(0.78);
                        follower.setMaxPower(0.78);
                        follower.followPath(Pre_keep1);
                        setPathState(2);
                        break;
                    }
                case 2:
                    if (!follower.isBusy()){
                        follower.setMaxPower(0.5);
                        follower.followPath(keep_1);
                        setPathState(3);
                        break;
                    }
                case 3:
                    if (!follower.isBusy()){
                        Thread.sleep(600);
                        follower.setMaxPower(1);
                        follower.followPath(scoring2,true);
                        Thread.sleep(400);
                        setPathState(102);
                        break;
                    }
                case 102:
                    if (!follower.isBusy()){

                        for (int i = 0; i <= 3; i++) {
                            switch (i) {
                                case 0:
                                    TopShooter.setPower(0.84);
                                    LowerShooter.setPower(0.84);
                                    break;
                                case 1:
                                    TopShooter.setPower(0.85);
                                    LowerShooter.setPower(0.85);
                                    break;
                                case 2:
                                    TopShooter.setPower(0.86);
                                    LowerShooter.setPower(0.86);
                                    break;
                            }

                            S3.setPosition(0.66);
                            S4.setPosition(0.52);
                            Middle.setPower(1);
                            Thread.sleep(300);

                            S3.setPosition(0);
                            S4.setPosition(0.36);
                            Middle.setPower(-0.9);
                            Thread.sleep(300);

                            Front.setPower(1);
                            Middle.setPower(1);
                            Thread.sleep(500);

                            Front.setPower(0);
                            Middle.setPower(0);
                            Thread.sleep(10);
                        }

                        setPathState(4);
                        break;
                    }
                case 4:
                    if (!follower.isBusy()){
                        Front.setPower(0.78);
                        follower.setMaxPower(0.78);
                        follower.followPath(Pre_keep2);
                        setPathState(5);
                        break;
                    }
                case 5:
                    if (!follower.isBusy()){
                        follower.setMaxPower(0.5);
                        follower.followPath(keep_2);
                        setPathState(6);
                        break;
                    }
                case 6:
                    if (!follower.isBusy()){
                        Thread.sleep(600);
                        follower.setMaxPower(1);
                        follower.followPath(scoring3,true);
                        Thread.sleep(400);
                        setPathState(103);
                        break;
                    }
                case 103:
                    if (!follower.isBusy()){

                        for (int i = 0; i <= 3; i++) {
                            switch (i) {
                                case 0:
                                    TopShooter.setPower(0.84);
                                    LowerShooter.setPower(0.84);
                                    break;
                                case 1:
                                    TopShooter.setPower(0.85);
                                    LowerShooter.setPower(0.85);
                                    break;
                                case 2:
                                    TopShooter.setPower(0.89);
                                    LowerShooter.setPower(0.89);
                                    break;
                            }

                            S3.setPosition(0.66);
                            S4.setPosition(0.52);
                            Middle.setPower(1);
                            Thread.sleep(300);

                            S3.setPosition(0);
                            S4.setPosition(0.36);
                            Middle.setPower(-0.9);
                            Thread.sleep(300);

                            Front.setPower(1);
                            Middle.setPower(1);
                            Thread.sleep(500);

                            Front.setPower(0);
                            Middle.setPower(0);
                            Thread.sleep(10);
                        }

                        setPathState(10);
                        break;
                    }
                case 10:
                    if (!follower.isBusy()){
                        follower.setMaxPower(1);
                        follower.followPath(Finale);

                        setPathState(11);
                        break;
                    }
            }
        }

        /** These change the states of the paths and actions. It will also reset the timers of the individual switches **/

        /**
         * These change the states of the paths and actions
         * It will also reset the timers of the individual switches
         **/
        public void setPathState(int pState) {
            pathState = pState;
            pathTimer.resetTimer();
        }


        @Override
        public void loop() {


            // These loop the movements of the robot
            follower.update();

            try {
                autonomousPathUpdate();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            // Feedback to Driver Hub
            telemetry.addData("path state", pathState);
            telemetry.addData("x", follower.getPose().getX());
            telemetry.addData("y", follower.getPose().getY());
            telemetry.addData("heading", follower.getPose().getHeading());
        }

        /**
         * This method is called once at the init of the OpMode.
         **/
        @Override
        public void init() {
            pathTimer = new Timer();
            opmodeTimer = new Timer();

            opmodeTimer.resetTimer();

            follower = Constants.createFollower(hardwareMap);
            buildPaths();
            follower.setStartingPose(startPose);

            rightRear = hardwareMap.get(DcMotor.class, "rightRear");
            rightFront = hardwareMap.get(DcMotor.class, "rightFront");
            leftRear = hardwareMap.get(DcMotor.class, "leftRear");
            leftFront = hardwareMap.get(DcMotor.class, "leftFront");

            S1 = hardwareMap.get(Servo.class, "S1");
            S2 = hardwareMap.get(Servo.class, "S2");
            S3 = hardwareMap.get(Servo.class, "S3");
            S4 = hardwareMap.get(Servo.class, "S4");

            Front = hardwareMap.get(DcMotor.class, "Front");
            Middle = hardwareMap.get(DcMotor.class, "Middle");

            LowerShooter = hardwareMap.get(DcMotor.class, "LowerShooter");
            TopShooter = hardwareMap.get(DcMotor.class, "TopShooter");

            rightRear.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
            rightFront.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
            leftRear.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
            leftFront.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

            leftRear.setDirection(DcMotor.Direction.REVERSE);
            leftFront.setDirection(DcMotor.Direction.REVERSE);

            Front.setDirection(DcMotor.Direction.REVERSE);
            Middle.setDirection(DcMotor.Direction.REVERSE);

            S1.setDirection(Servo.Direction.REVERSE);
            S2.setDirection(Servo.Direction.FORWARD);
            S3.setDirection(Servo.Direction.REVERSE);
            S4.setDirection(Servo.Direction.REVERSE);

            LowerShooter.setDirection(DcMotor.Direction.REVERSE);
            TopShooter.setDirection(DcMotor.Direction.REVERSE);





        }


        /**
         * This method is called continuously after Init while waiting for "play".
         **/
        @Override
        public void init_loop() {
        }

        /**
         * This method is called once at the start of the OpMode.
         * It runs all the setup actions, including building paths and starting the path system
         **/
        @Override
        public void start() {
            opmodeTimer.resetTimer();
            setPathState(0);

        }


        @Override
        public void stop() {
        }

    }
